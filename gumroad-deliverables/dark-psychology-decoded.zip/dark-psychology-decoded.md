# Dark Psychology Decoded — Manipulation Defense Toolkit

An educational guide to recognizing and defending against manipulation tactics.
Knowledge is defense: this toolkit is for protection, not for harming others.

## 10 Common Manipulation Tactics

### Love bombing
Overwhelming affection early to create dependency. Defense: slow the pace, watch for pressure.

### Gaslighting
Making you doubt your own memory or perception. Defense: keep a written record, trust the facts.

### Guilt-tripping
Using obligation to extract compliance. Defense: separate their feelings from your responsibility.

### Silent treatment
Withdrawal as punishment. Defense: don't chase; state your boundary once and wait.

### Triangulation
Dragging a third party in to pressure you. Defense: refuse to engage through intermediaries.

### Moving goalposts
Shifting criteria so you can never 'win'. Defense: name the shift, hold the original agreement.

### Negging / backhanded compliments
Disguised insults to lower your confidence. Defense: call it out or disengage.

### Fear-mongering
Exaggerated threats to force a fast decision. Defense: buy time, verify claims.

### Isolation
Cutting you off from support networks. Defense: protect your outside relationships deliberately.

### Future faking
Promising a future that never arrives. Defense: judge actions, not promises.

## 8 Red Flags to Watch For

- You feel confused or 'crazy' after conversations
- You're always the one apologizing
- Your time/attention is treated as owed
- Boundaries are met with anger or guilt
- They rewrite history to their benefit
- You're rushed into decisions
- Your support network is criticized
- Promises never turn into actions

## 7 Defense Strategies

- Name the behavior — labeling reduces its power.
- Pause before responding — urgency is a tool of control.
- Use short, firm phrases: 'That doesn't work for me.'
- Document what happened in writing.
- Lean on your outside support network.
- Enforce consequences when boundaries are crossed.
- When in doubt, exit the situation.

## What to Say — Scripts for Each Defense

### Name the behavior
"That sounds like you're [gaslighting/guilt-tripping/moving goalposts]. I'm going to step back from this."

### Pause before responding
"I need time to think about this. I'll get back to you tomorrow."

### Short firm phrases
"That doesn't work for me." / "No, I'm not able to do that." / "I won't be discussing this further."

### Document in writing
"Let me send you a quick note so we're both on the same page about what was agreed."

### Lean on your network
"Let me check with [friend/family] before I decide."

### Enforce consequences
"If you raise your voice, I'll end this conversation. We can continue when it's calm."

### Exit the situation
"I'm not comfortable with how this is going. I'm going to leave now."


## Real-World Scenario Walkthroughs

### Scenario 1 — The rush to close
**Setup:** A salesperson or partner insists you decide today because the offer 'expires tonight.'
**Resolution:** Tactic: fear-mongering + moving goalposts. Response: 'If it's a good offer, it'll be good tomorrow. I'll decide on my own timeline.'

### Scenario 2 — The slow erosion
**Setup:** A friend consistently 'forgets' commitments and makes you feel unreasonable for being upset.
**Resolution:** Tactic: gaslighting. Response: write the facts down, trust your record, and state the boundary once without re-litigating.

### Scenario 3 — The guilt spiral
**Setup:** A family member implies your boundaries mean you don't care about them.
**Resolution:** Tactic: guilt-tripping. Response: separate their feelings from your responsibility: 'I care about you, and I still need to say no.'

### Scenario 4 — The triangulated message
**Setup:** A third party relays what someone 'really thinks' of you to pressure a choice.
**Resolution:** Tactic: triangulation. Response: 'Please have them talk to me directly. I won't negotiate through other people.'

### Scenario 5 — The affection flood
**Setup:** A new relationship escalates unusually fast with gifts, praise, and constant contact.
**Resolution:** Tactic: love bombing. Response: slow the pace deliberately and watch whether affection turns to pressure when you set a limit.


## 30-Day Awareness Log Template

For 30 days, note one interaction per day. Pattern-spotting is the point.

| Day | Who | What happened | Tactic (if any) | How I responded | Better next time |
|---|---|---|---|---|---|
| 1 |  |  |  |  |  |
| 2 |  |  |  |  |  |
| 3 |  |  |  |  |  |
| 4 |  |  |  |  |  |
| 5 |  |  |  |  |  |
| 6 |  |  |  |  |  |
| 7 |  |  |  |  |  |
| 8 |  |  |  |  |  |
| 9 |  |  |  |  |  |
| 10 |  |  |  |  |  |
| 11 |  |  |  |  |  |
| 12 |  |  |  |  |  |
| 13 |  |  |  |  |  |
| 14 |  |  |  |  |  |
| 15 |  |  |  |  |  |
| 16 |  |  |  |  |  |
| 17 |  |  |  |  |  |
| 18 |  |  |  |  |  |
| 19 |  |  |  |  |  |
| 20 |  |  |  |  |  |
| 21 |  |  |  |  |  |
| 22 |  |  |  |  |  |
| 23 |  |  |  |  |  |
| 24 |  |  |  |  |  |
| 25 |  |  |  |  |  |
| 26 |  |  |  |  |  |
| 27 |  |  |  |  |  |
| 28 |  |  |  |  |  |
| 29 |  |  |  |  |  |
| 30 |  |  |  |  |  |

## Further Reading

- Harriet B. Braiker — *Who's Pulling Your Strings?* (patterns of manipulation)
- George K. Simon — *In Sheep's Clothing* (covert-aggressive personalities)
- Robert Cialdini — *Influence* (the psychology of persuasion, to recognize it)
- Lundy Bancroft — *Why Does He Do That?* (abusive control patterns)

## Ethical note
Use these patterns to protect yourself and others. Never use them to manipulate.

© KRK Reviews — educational use only.
