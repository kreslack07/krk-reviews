# Stoic Wisdom Journal — 90 Daily Prompts

90 daily reflection prompts across 12 Stoic themes. One prompt a day, morning or evening.

## Week 1 — Perception

1. What within my control am I ignoring today?
2. Which event am I adding a story to, beyond the facts?
3. What would the wisest person I know notice about this moment?
4. Am I confusing 'uncomfortable' with 'bad'?
5. What am I taking personally that isn't about me?
6. What does this situation look like a year from now?
7. Where am I assuming the worst before evidence?

## Week 2 — Action

8. What is the next right action, however small?
9. What am I avoiding by staying busy?
10. What would I do if I weren't afraid of judgment?
11. Where am I overcomplicating a simple choice?
12. What duty am I neglecting?
13. What does courage look like in today's actual challenges?
14. What habit, done daily, would compound most?

## Week 3 — Will / Acceptance

15. What am I fighting that I cannot change?
16. Where am I confusing preference with need?
17. What outcome am I clinging to?
18. What would acceptance of this moment look like?
19. Where am I letting desire run the day?
20. What am I grateful for that I treat as guaranteed?
21. What am I refusing to accept that I should?

## Week 4 — Mortality

22. If today were my last, what would I stop doing?
23. Who would I contact today if time were short?
24. What am I postponing as if I have forever?
25. What will I regret not having started?
26. What does 'memento mori' mean for my calendar today?
27. Where am I wasting the one resource I can't renew?
28. What kindness have I left undone?

## Week 5 — Character

29. What would my behavior say about me to a stranger?
30. Where do my actions contradict my stated values?
31. What temptation tests my integrity most?
32. Whom am I becoming through daily repetition?
33. What would I change if no one would ever know?
34. Which virtue do I most need to strengthen now?
35. What would the ideal version of me do here?

## Week 6 — Relationships

36. How would I treat this person if I expected nothing in return?
37. Where am I taking a relationship for granted?
38. What expectation am I silently holding?
39. How might this person's actions make sense from their view?
40. What would patience look like in this relationship today?
41. Where am I needing to be right more than kind?
42. What can I offer today without keeping score?

## Week 7 — Adversity

43. What is this obstacle teaching me?
44. What strength is this difficulty building?
45. What would I tell a friend facing this same challenge?
46. Where is the opportunity inside this setback?
47. What have I already survived that proves I can do this?
48. What part of this struggle is optional?
49. What is the gift hidden in this problem?
50. What does my response to this reveal about me?

## Week 8 — Wealth & Ambition

51. What am I pursuing that won't satisfy once I have it?
52. What does 'enough' actually look like for me?
53. Where am I chasing status over substance?
54. What would I do with my ambition if fear weren't involved?
55. Am I measuring success by my own standard or someone else's?
56. What have I gained that I now take for granted?
57. What is the true cost of what I'm chasing?
58. What would I stop chasing if I trusted the future?

## Week 9 — Anger & Emotion

59. What am I believing that is fueling this anger?
60. What does my anger want to protect?
61. How much of this reaction is about the past, not the present?
62. What would calm look like in this exact moment?
63. Where am I outsourcing my emotional state to others?
64. What is the pause between trigger and response asking of me?
65. What would I lose by not reacting at all?
66. What is the calm response this situation deserves?

## Week 10 — Gratitude

67. What ordinary thing am I failing to notice today?
68. Whom am I grateful for that I haven't thanked?
69. What discomfort am I actually fortunate to have?
70. What would I miss most if it were gone tomorrow?
71. What small kindness did I receive today?
72. What is working in my life that I overlook?
73. What does gratitude change about this problem?
74. What ordinary blessing did I take for granted today?

## Week 11 — Focus & Discipline

75. What is the one thing that matters most today?
76. Where am I confusing activity with progress?
77. What distraction am I choosing over what matters?
78. What does discipline look like when no one is watching?
79. What am I tolerating that I know I should change?
80. Where is my attention leaking away?
81. What would I prioritize if I had half the time?
82. What is the one distraction I will drop today?

## Week 12 — Purpose & Legacy

83. What do I want to be remembered for?
84. What work feels worth doing even without reward?
85. Where am I living someone else's plan?
86. What would I pursue if I knew I couldn't fail?
87. What is the through-line of my best days?
88. What am I here to contribute?
89. What is the difference I want to leave behind?
90. What legacy am I already building through today's choices?

## How to use
Pick a prompt, write for 10 minutes without editing. Return weekly to spot patterns.

© KRK Reviews — for personal use.
