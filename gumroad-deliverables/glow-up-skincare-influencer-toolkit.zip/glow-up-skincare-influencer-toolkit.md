# Glow Up Skincare Influencer Toolkit

Routine templates, content pillars, and a growth playbook for skincare creators.

## 8 Content Pillars

- **Routine Reveals** — Show the actual process: morning, evening, weekly reset.
- **Ingredient Education** — Teach one ingredient at a time, simply.
- **Myth Busting** — Debunk a common skincare myth with evidence.
- **Progress Check-ins** — Bare-face updates build trust and retention.
- **Product Deep Dives** — One product, full honest review, repurchase verdict.
- **Budget vs Luxury** — Compare $ vs $$$$ versions of the same step.
- **Skin Science** — Break down barrier, pH, purging in plain words.
- **Community Q&A** — Answer follower questions on camera.

## Routine Templates

### Beginner (3 steps)
- Gentle cleanser
- Moisturizer
- SPF 30+ (morning)

### Core (5 steps)
- Cleanser
- Treatment serum
- Moisturizer
- SPF (AM)
- Cleanser (PM)

### Advanced (7 steps)
- Double cleanse
- Exfoliant (2-3x/wk)
- Treatment
- Moisturizer
- Eye cream
- SPF
- Night mask

## Growth Playbook

- Post 1x daily for 30 days before judging results.
- Pin your best-performing routine reveal.
- Reply to every comment in the first hour.
- Use the same lighting and angle for before/after trust.
- Hook in the first 2 seconds — no intro fluff.
- Turn one video into 5: long-form, short, carousel, story, text post.
- Track which ingredient gets the most saves and go deeper.

## 25 Hooks That Stop the Scroll

1. My $8 cleanser out-cleaned my $40 one
2. 3 steps, 3 products, zero fluff
3. The ingredient doing the most (and it's not retinol)
4. Stop double-cleansing. Do this instead
5. What I'd buy with $100 for my skin
6. The routine I'd give my past self
7. Your moisturizer is fine. Your barrier isn't
8. The one step everyone skips
9. I tested drugstore vs luxury for 30 days
10. What 'skin cycling' actually means
11. The purge everyone warns you about
12. How I got my texture smooth (finally)
13. The SPF rule that changed my skin
14. Why your toner is doing nothing
15. The $12 serum with a cult following
16. What broke me out (and what didn't)
17. The 2-minute lazy-skin routine
18. My honest review of the viral product
19. The ingredient I'd ban from my shelf
20. How to build a routine from zero
21. The before/after I almost didn't post
22. Why I stopped using 12 products
23. The hydration vs moisture mistake
24. What cleared my acne (not what I expected)
25. The routine I'd recommend to a friend

## 5 Caption Templates

1. **Routine reveal:** "My [AM/PM] routine, 60 seconds, zero fluff. What's in your routine? Drop it below."
2. **Ingredient explainer:** "What [ingredient] actually does — and what it doesn't. Save this for your next shop."
3. **Myth bust:** "You've heard [myth]. Here's what's actually true."
4. **Before/after:** "30 days, same lighting, no filter. The difference? [one change]."
5. **Question post:** "What's the one skincare question you've always wanted answered? I'll cover it."

## 30 Content Ideas (one per day)

1. Morning routine step-by-step
2. Evening routine step-by-step
3. Skin type explainer
4. Ingredient spotlight (pick one)
5. Myth vs fact
6. Weekly bare-face check-in
7. Budget routine under $30
8. How to read INCI labels
9. Patch-test demo
10. 'Natural vs safe' explainer
11. Sunscreen 101
12. Two-week progress update
13. Ingredient spotlight #2
14. Night routine deep-dive
15. Pores myth-bust
16. Travel skincare edit
17. Viral product breakdown
18. Ingredient spotlight #3
19. Three-week check-in
20. Acne vs purge explainer
21. DIY caution list
22. Skin barrier explainer
23. Ingredient spotlight #4
24. Honest before/after photography
25. Myth: water = clear skin
26. Product empties review
27. Routine recap
28. Ingredient spotlight #5
29. What I'd repurchase
30. 30-day results reveal

## Weekly Planner (4 weeks)

- **Week 1 — Foundation:** routine + skin type + one ingredient. Goal: consistency.
- **Week 2 — Education:** ingredient spotlights + myth busts. Goal: trust.
- **Week 3 — Authority:** product deep dives + budget vs luxury. Goal: expertise signal.
- **Week 4 — Conversion:** results + repurchase verdict + community Q&A. Goal: engagement + saves.

## Ingredient Cheat Sheet

- **Niacinamide** — Vitamin B3. Regulates oil, fades dark spots, strengthens the barrier. Tolerated by most.
- **Hyaluronic acid** — Humectant that pulls water into the skin. Best on damp skin, sealed with moisturizer.
- **Salicylic acid (BHA)** — Oil-soluble exfoliant that clears pores. Best for blackheads and oily skin.
- **Glycolic acid (AHA)** — Water-soluble exfoliant that brightens and smooths texture. Strongest AHA.
- **Retinol** — Vitamin A. The gold-standard for fine lines and acne, but start slow and low.
- **Vitamin C** — Antioxidant that brightens and supports collagen. Use in the morning under SPF.
- **Ceramides** — Lipids that rebuild the skin barrier. Essential after any over-exfoliation.
- **Peptides** — Short chains of amino acids that signal collagen production. Gentle and hydrating.
- **Squalane** — Lightweight moisturizing oil that mimics skin's own sebum. Safe for most acne-prone skin.
- **Benzoyl peroxide** — Antibacterial for acne. Effective but can bleach fabrics and dry skin.

## Skin-Type Routine Matrix

| Skin type | Morning | Evening |
|---|---|---|
| Dry | Gentle cleanse → hyaluronic → rich moisturizer → SPF | Cleanse → hyaluronic → ceramide cream → oil |
| Oily | Foam cleanse → niacinamide → light gel moisturizer → SPF | Cleanse → BHA (2-3x/wk) → niacinamide → gel |
| Combination | Gentle cleanse → niacinamide → moisturizer (cheeks) → SPF | Cleanse → AHA (2x/wk) → moisturizer |
| Sensitive | Water rinse or micellar → barrier cream → mineral SPF | Cleanse → ceramide cream → no actives |

© KRK Reviews — for personal use.
